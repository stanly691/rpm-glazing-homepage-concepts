/**
 * Join form polish (Gravity Forms form 1):
 * - "Your plan" summary with a Change link on steps 2 and 3
 * - instant, friendly validation before a step is sent to the server
 * - loading state on the step buttons
 * - smooth scroll between steps, focus on the first field (desktop)
 * - checks a field when the person leaves it (only if they typed something)
 * - single date of birth field with DD/MM/YYYY mask, email typo suggestions
 */
(function ($) {
	var FORM_ID = 1;
	var BACK_KEY = 'bgwc-back-to-plan';
	var PLAN_KEY = 'bgwc-plan';
	var SELECT_KEY = 'bgwc-select-plan';
	var lastPage = null;
	var finePointer = window.matchMedia && window.matchMedia('(pointer: fine)').matches;
	var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function store(key, value) {
		try {
			if (value === null) {
				sessionStorage.removeItem(key);
			} else {
				sessionStorage.setItem(key, value);
			}
		} catch (e) {}
	}

	function read(key) {
		try {
			return sessionStorage.getItem(key);
		} catch (e) {
			return null;
		}
	}

	function isShown($el) {
		return $el.closest('.gfield').css('display') !== 'none' && $el.closest('.gform_page').css('display') !== 'none';
	}

	/* ---------- Plan summary ---------- */

	function chosenPlan($form) {
		var $join = $form.find('input[name="input_2"]:checked');
		if ($join.length && /GP referral/.test($join.val())) {
			return { name: 'GP referral', price: 'Free' };
		}
		var $plan = $form.find('input[name="input_3"]:checked, input[name="input_4"]:checked').filter(function () {
			return $(this).closest('.gfield').css('display') !== 'none';
		}).first();
		if (!$plan.length) {
			return null;
		}
		var $label = $form.find('label[for="' + $plan.attr('id') + '"]');
		var name = $plan.val().split('|')[0];
		var $concession = $form.find('input[name="input_29"]:checked');
		if (/concession/.test(name) && $concession.length) {
			name += ' (' + $concession.val() + ')';
		}
		return { name: name, price: $.trim($label.find('.bgwc-price').text()) };
	}

	function remember($form) {
		var plan = chosenPlan($form);
		store(PLAN_KEY, plan ? JSON.stringify(plan) : null);
	}

	function summaryBar(page) {
		var plan = null;
		try {
			plan = JSON.parse(read(PLAN_KEY) || 'null');
		} catch (e) {}
		if (!plan) {
			return;
		}
		var $bar = $(
			'<div class="bgwc-summary" role="status">' +
				'<span class="bgwc-summary__label">Your plan</span>' +
				'<span class="bgwc-summary__name"></span>' +
				'<span class="bgwc-summary__price"></span>' +
				'<a href="#" class="bgwc-summary__change" role="button">Change</a>' +
			'</div>'
		);
		$bar.find('.bgwc-summary__name').text(plan.name);
		$bar.find('.bgwc-summary__price').text(plan.price);
		$bar.find('.bgwc-summary__change').on('click', function (event) {
			event.preventDefault();
			goToPlan(page, null);
		});
		$('#gform_page_' + FORM_ID + '_' + page + ' .gform_page_fields').before($bar);
	}

	/* ---------- Instant validation ---------- */

	var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

	function setError($field, message) {
		$field.addClass('bgwc-invalid');
		var $msg = $field.find('.bgwc-error');
		if (!$msg.length) {
			$msg = $('<div class="bgwc-error" role="alert"></div>').appendTo($field);
		}
		$msg.text(message);

		// Under 13 filling it in themselves: one tap hands over to a parent or guardian.
		if ($field.hasClass('gfield--type-date') && /under 13/.test(message)) {
			$('<a href="#" class="bgwc-error__fix"></a>').text('I’m their parent or guardian – switch →').on('click', function (event) {
				event.preventDefault();
				var $parent = $field.closest('form').find('input[name="input_8"]').filter(function () {
					return /parent/.test(this.value);
				});
				$parent.prop('checked', true).trigger('click').trigger('change');
			}).appendTo($msg.append(' '));
		}

		// Plan doesn't fit the age: offer the plan that does.
		if ($field.hasClass('gfield--type-date') && / (are|is) for (ages|under)/.test(message)) {
			var $form = $field.closest('form');
			var tip = suggestPlan($form, ageOn($field.find('input[type=text]').val()));
			var page = parseInt($field.closest('.gform_page').attr('id').split('_').pop(), 10);
			var $link = $('<a href="#" class="bgwc-error__fix"></a>')
				.text(tip ? 'Switch to ' + tip.name + ' →' : 'Choose a different plan →')
				.on('click', function (event) {
					event.preventDefault();
					goToPlan(page, tip && tip.id);
				});
			$msg.append(' ').append($link);
		}
	}

	function clearError($field) {
		$field.removeClass('bgwc-invalid').find('.bgwc-error').remove();
	}

	function checkField($field) {
		if ($field.css('display') === 'none' || !$field.hasClass('gfield_contains_required')) {
			return true;
		}
		var $radios = $field.find('input[type=radio]');
		if ($radios.length) {
			return $radios.filter(':checked').length ? true : 'Please choose one to continue.';
		}
		var $consent = $field.find('input[type=checkbox]');
		if ($field.hasClass('gfield--type-consent')) {
			return $consent.is(':checked') ? true : 'Please tick to confirm.';
		}
		var $inputs = $field.find('input[type=text], input[type=email], input[type=tel], input[type=number], textarea').filter(function () {
			return $(this).closest('.gform-grid-col, .ginput_container').css('display') !== 'none' && this.type !== 'hidden';
		});
		var empty = $inputs.filter(function () {
			return !$.trim(this.value);
		});
		if (empty.length) {
			return $field.hasClass('gfield--type-date') ? 'Please enter the date of birth.' : 'Please fill this in.';
		}
		if ($field.hasClass('gfield--type-date')) {
			if (!validDate($inputs.first().val())) {
				return 'Please enter the date of birth as DD/MM/YYYY.';
			}
			var ageProblem = checkAge($field.closest('form'), $inputs.first().val());
			if (ageProblem) {
				return ageProblem;
			}
		}
		var $email = $field.find('input[type=email]');
		if ($email.length && !EMAIL.test($.trim($email.val()))) {
			return 'Please enter a valid email address.';
		}
		var $tel = $field.find('input[type=tel]');
		if ($tel.length && $tel.val().replace(/\D/g, '').length < 10) {
			return 'Please enter a valid phone number.';
		}
		return true;
	}

	function validatePage($page) {
		var $first = null;
		$page.find('.gfield').each(function () {
			var $field = $(this);
			var result = checkField($field);
			if (result === true) {
				clearError($field);
			} else {
				setError($field, result);
				$first = $first || $field;
			}
		});
		if ($first) {
			scrollTo($first, -24);
			var $focus = $first.find('input:not([type=hidden]), textarea').first();
			setTimeout(function () {
				$focus.trigger('focus', { preventScroll: true });
			}, reduceMotion ? 0 : 350);
			return false;
		}
		return true;
	}

	function validDate(value) {
		var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec($.trim(value));
		if (!m) {
			return false;
		}
		var d = new Date(+m[3], +m[2] - 1, +m[1]);
		var year = new Date().getFullYear();
		return d.getDate() === +m[1] && d.getMonth() === +m[2] - 1 && +m[3] > year - 110 && d <= new Date();
	}

	/* ---------- Plan and age rules (mirrored on the server in functions.php) ---------- */

	function ageOn(value) {
		var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec($.trim(value));
		var now = new Date();
		var age = now.getFullYear() - +m[3];
		if (now.getMonth() + 1 < +m[2] || (now.getMonth() + 1 === +m[2] && now.getDate() < +m[1])) {
			age--;
		}
		return age;
	}

	function checkAge($form, value) {
		var join = $form.find('input[name="input_2"]:checked').val() || '';
		var planInput = /Pay as you go/.test(join) ? 'input_4' : 'input_3';
		var plan = /GP referral/.test(join) ? '' : ($form.find('input[name="' + planInput + '"]:checked').val() || '').split('|')[0];
		var who = $form.find('input[name="input_8"]:checked').val() || '';
		return ageProblem(ageOn(value), join, plan, who);
	}

	// Pure rules: mirrored by bgwc_age_problem() in functions.php.
	function ageProblem(age, join, plan, who) {
		if (/joining/.test(who) && age < 13) {
			return 'As you’re under 13, a parent or guardian needs to fill this in.';
		}
		var rules = [];
		if (/junior/i.test(plan)) {
			rules.push([11, 15, 'Junior plans are for ages 11–15']);
		} else if (/Children/.test(plan)) {
			rules.push([0, 15, 'The children’s wellbeing gym is for under-16s']);
		} else if (/16\+/.test(plan)) {
			rules.push([16, 200, 'Adult plans are for ages 16 and over']);
		} else if (/concession/.test(plan)) {
			rules.push([16, 200, 'Concession memberships are for ages 16 and over']);
		} else if (/Dual/.test(plan)) {
			rules.push([16, 200, 'The dual BJJ + gym membership is for ages 16 and over']);
		}
		if (/GP referral/.test(join)) {
			rules.push([16, 25, 'GP referrals are for ages 16–25']);
		}
		for (var i = 0; i < rules.length; i++) {
			if (age < rules[i][0] || age > rules[i][1]) {
				return rules[i][2] + ', but this date of birth makes them ' + age + '. Please change the plan or check the date.';
			}
		}
		return '';
	}

	// The plan that fits this age, for the one-tap "Switch to ..." fix.
	function suggestPlan($form, age) {
		var join = $form.find('input[name="input_2"]:checked').val() || '';
		if (/GP referral/.test(join)) {
			return null;
		}
		var payg = /Pay as you go/.test(join);
		var name = age < 11 ? (payg ? 'Children’s wellbeing gym – single session' : 'Children’s wellbeing gym')
			: age < 16 ? (payg ? 'Day pass – junior (11–15)' : 'Gym – junior (11–15)')
			: (payg ? 'Day pass – adult (16+)' : 'Gym – adult (16+)');
		var $input = $form.find('input[name="' + (payg ? 'input_4' : 'input_3') + '"]').filter(function () {
			return this.value.split('|')[0] === name;
		});
		return $input.length && !$input.is(':checked') ? { name: name, id: $input.attr('id') } : null;
	}

	function goToPlan(page, inputId) {
		store(SELECT_KEY, inputId || null);
		store(BACK_KEY, '1');
		$('#gform_page_' + FORM_ID + '_' + page + ' .gform_previous_button').trigger('click');
	}

	/* ---------- Helpers ---------- */

	function scrollTo($el, offset) {
		if (!$el.length) {
			return;
		}
		var top = $el[0].getBoundingClientRect().top + window.pageYOffset + (offset || 0);
		window.scrollTo({ top: Math.max(top, 0), behavior: reduceMotion ? 'auto' : 'smooth' });
	}

	function nudgeFooter($page) {
		if (finePointer) {
			return;
		}
		var $footer = $page.find('.gform_page_footer, .gform_footer').first();
		if (!$footer.length) {
			return;
		}
		$footer.removeClass('bgwc-nudge');
		void $footer[0].offsetWidth;
		$footer.addClass('bgwc-nudge');
	}

	var TYPO_DOMAINS = {
		'gmial.com': 'gmail.com', 'gamil.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gmail.co': 'gmail.com', 'gmail.co.uk': 'gmail.com', 'gnail.com': 'gmail.com',
		'hotmial.com': 'hotmail.com', 'hotmal.com': 'hotmail.com', 'hotmail.co': 'hotmail.co.uk', 'hotmai.co.uk': 'hotmail.co.uk',
		'outlok.com': 'outlook.com', 'outloo.com': 'outlook.com', 'outlook.co': 'outlook.com',
		'yahooo.com': 'yahoo.com', 'yaho.com': 'yahoo.com', 'yahoo.co': 'yahoo.co.uk',
		'icloud.co': 'icloud.com', 'iclod.com': 'icloud.com', 'icoud.com': 'icloud.com', 'icloud.co.uk': 'icloud.com'
	};

	function suggestEmail($input) {
		var $field = $input.closest('.gfield');
		$field.find('.bgwc-suggest').remove();
		var value = $.trim($input.val()).toLowerCase();
		var at = value.lastIndexOf('@');
		if (at < 1) {
			return;
		}
		var fix = TYPO_DOMAINS[value.slice(at + 1)];
		if (!fix) {
			return;
		}
		var suggestion = value.slice(0, at + 1) + fix;
		var $hint = $('<div class="bgwc-suggest">Did you mean <a href="#"></a>?</div>');
		$hint.find('a').text(suggestion).on('click', function (event) {
			event.preventDefault();
			$input.val(suggestion).trigger('change');
			$hint.remove();
			clearError($field);
		});
		$input.closest('.ginput_container').after($hint);
	}

	/* ---------- Gliding pill for the toggles ---------- */

	function placePill($group, animate) {
		var $pill = $group.children('.bgwc-pill');
		var $label = $group.find('input:checked').closest('.gchoice').find('label');
		if (!$label.length) {
			$pill.css('opacity', 0);
			return;
		}
		var el = $label[0];
		if (!el.offsetWidth) {
			return;
		}
		$pill.data('placed', true);
		var group = $group[0];
		var g = group.getBoundingClientRect();
		var r = el.getBoundingClientRect();
		var x = r.left - g.left - group.clientLeft;
		var y = r.top - g.top - group.clientTop;
		if (!animate) {
			$pill.addClass('bgwc-pill--instant');
		}
		$pill.css({
			opacity: 1,
			width: el.offsetWidth + 'px',
			height: el.offsetHeight + 'px',
			transform: 'translate(' + x + 'px,' + y + 'px)'
		});
		if (!animate) {
			void $pill[0].offsetWidth;
			$pill.removeClass('bgwc-pill--instant');
		}
	}

	function setupPills($form) {
		$form.find('.bgwc-tabs .gfield_radio').each(function () {
			var $group = $(this);
			if (!$group.children('.bgwc-pill').length) {
				$group.addClass('bgwc-has-pill').prepend('<span class="bgwc-pill" aria-hidden="true"></span>');
			}
			if ($group.is(':visible')) {
				placePill($group, false);
			}
		});
		$form.off('change.bgwcp').on('change.bgwcp', '.bgwc-tabs input[type=radio]', function () {
			placePill($(this).closest('.gfield_radio'), true);
		});
		// Groups that were hidden (e.g. "Which concession?") need placing once shown.
		$(document).off('gform_post_conditional_logic.bgwcp').on('gform_post_conditional_logic.bgwcp', function () {
			$form.find('.bgwc-tabs .gfield_radio:visible').each(function () {
				var $pill = $(this).children('.bgwc-pill');
				if (!$pill.data('placed')) {
					placePill($(this), false);
				}
			});
		});
	}

	var resizeTimer;
	$(window).on('resize', function () {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(function () {
			$('#gform_' + FORM_ID + ' .bgwc-tabs .gfield_radio:visible').each(function () {
				placePill($(this), false);
			});
		}, 100);
	});

	/* ---------- Who's filling this in / under 18 ---------- */

	function isParentFilling($form) {
		return /parent/.test($form.find('input[name="input_8"]:checked').val() || '');
	}

	// Mirrors the server: field 31 is "yes" when the member is under 18.
	function updateMinorFlag($form) {
		var value = $.trim($form.find('#input_' + FORM_ID + '_10').val());
		if (!validDate(value)) {
			return; // keep the last known answer while the date is being edited
		}
		var flag = ageOn(value) < 18 ? 'yes' : 'no';
		var $flag = $form.find('#input_' + FORM_ID + '_31');
		if ($flag.val() !== flag) {
			$flag.val(flag);
			if (window.gf_apply_rules) {
				window.gf_apply_rules(FORM_ID, [15, 16, 32, 33], false);
			}
		}
	}

	function setLabel(fieldId, text) {
		$('#field_' + FORM_ID + '_' + fieldId).find('.gfield_label .gform-field-label__text, legend.gfield_label .gform-field-label__text').first().text(text);
	}

	function updateLabels($form) {
		var parent = isParentFilling($form);
		setLabel(9, parent ? 'Member’s name' : 'Your name');
		setLabel(10, parent ? 'Member’s date of birth' : 'Your date of birth');
		setLabel(11, 'Your email');
		setLabel(12, 'Your mobile number');
		setLabel(15, parent ? 'Your name (parent or guardian)' : 'Parent or guardian’s name');
	}

	// Emergency contact: one tap to reuse the parent or guardian's details.
	// The link is updated in place (never rebuilt) so a click is not lost when
	// leaving the name box fires a change event mid-click.
	function emergencyHelper($form) {
		var $field = $('#field_' + FORM_ID + '_18');
		var $link = $field.find('.bgwc-reuse');
		var parent = isParentFilling($form);
		var name = $.trim($form.find('#input_' + FORM_ID + '_15').val());
		var phone = $.trim($form.find(parent ? '#input_' + FORM_ID + '_12' : '#input_' + FORM_ID + '_16').val());
		var filled = $.trim($form.find('#input_' + FORM_ID + '_18').val()) || $.trim($form.find('#input_' + FORM_ID + '_19').val());
		if (!name || !phone || filled || $('#field_' + FORM_ID + '_15').css('display') === 'none') {
			$link.remove();
			return;
		}
		if (!$link.length) {
			$link = $('<a href="#" class="bgwc-reuse"></a>').on('click', function (event) {
				event.preventDefault();
				var $a = $(this);
				$form.find('#input_' + FORM_ID + '_18').val($a.data('name')).trigger('change');
				$form.find('#input_' + FORM_ID + '_19').val($a.data('phone')).trigger('change');
				clearError($field);
				clearError($('#field_' + FORM_ID + '_19'));
				$a.remove();
			}).insertAfter($field.find('.gfield_label').first());
		}
		$link.data({ name: name, phone: phone }).text('Use ' + name + '’s details');
	}

	/* ---------- Wiring ---------- */

	function enhance($form, page) {
		var $page = $('#gform_page_' + FORM_ID + '_' + page);
		setupPills($form);

		// Date of birth: one typed field, number keypad, slashes added automatically.
		var $dob = $form.find('#input_' + FORM_ID + '_10');
		$dob.attr({ inputmode: 'numeric', maxlength: 10 });
		$dob.off('input.bgwc').on('input.bgwc', function (event) {
			var deleting = event.originalEvent && /^delete/.test(event.originalEvent.inputType || '');
			var digits = this.value.replace(/\D/g, '').slice(0, 8);
			var out = digits.slice(0, 2);
			if (digits.length > 2 || (digits.length === 2 && !deleting)) {
				out += '/' + digits.slice(2, 4);
			}
			if (digits.length > 4 || (digits.length === 4 && !deleting)) {
				out += '/' + digits.slice(4);
			}
			this.value = out;
		});

		// Optional calendar: opens the device's own date picker, fills DD/MM/YYYY.
		if ($dob.length && !$dob.siblings('.bgwc-cal').length) {
			var today = new Date().toISOString().slice(0, 10);
			var $native = $('<input type="date" class="bgwc-cal__native" tabindex="-1" aria-hidden="true" min="1916-01-01">').attr('max', today);
			var $btn = $('<button type="button" class="bgwc-cal" aria-label="Choose date of birth from a calendar"></button>');
			$dob.after($btn, $native);
			$btn.on('click', function () {
				var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec($dob.val());
				$native.val(m ? m[3] + '-' + m[2] + '-' + m[1] : '');
				try {
					$native[0].showPicker();
				} catch (e) {
					$native.trigger('focus').trigger('click');
				}
			});
			$native.on('change', function () {
				var parts = this.value.split('-');
				if (parts.length === 3) {
					$dob.val(parts[2] + '/' + parts[1] + '/' + parts[0]).trigger('change');
					var $field = $dob.closest('.gfield');
					var picked = checkField($field);
					if (picked === true) {
						clearError($field);
					} else {
						setError($field, picked);
					}
				}
			});
		}

		// Under-18 flag, labels and helpers follow the date of birth and who's filling in.
		$dob.off('input.bgwcm change.bgwcm').on('input.bgwcm change.bgwcm', function () {
			updateMinorFlag($form);
		});
		$form.off('change.bgwcl').on('change.bgwcl', 'input[name="input_8"]', function () {
			updateLabels($form);
			emergencyHelper($form);
		});
		$form.off('input.bgwch change.bgwch').on('input.bgwch change.bgwch', '#input_' + FORM_ID + '_15, #input_' + FORM_ID + '_16, #input_' + FORM_ID + '_12', function () {
			emergencyHelper($form);
		});
		updateMinorFlag($form);
		updateLabels($form);
		emergencyHelper($form);

		// Re-check the date of birth when "Who's filling this in?" changes.
		$form.off('change.bgwcw').on('change.bgwcw', 'input[name="input_8"]', function () {
			var $dobField = $('#field_' + FORM_ID + '_10');
			if ($.trim($dob.val())) {
				var result = checkField($dobField);
				if (result === true) {
					clearError($dobField);
				} else {
					setError($dobField, result);
				}
			}
		});

		// Check a field when the person leaves it, but never flag an untouched empty field.
		$form.off('focusout.bgwcb').on('focusout.bgwcb', 'input[type=text], input[type=email], input[type=tel]', function () {
			if (!$.trim(this.value)) {
				return;
			}
			var $field = $(this).closest('.gfield');
			var result = checkField($field);
			if (result === true) {
				clearError($field);
			} else if (result !== 'Please fill this in.' && result !== 'Please enter the date of birth.') {
				setError($field, result);
			}
		});

		// Clear an error as soon as the field is fixed.
		$form.off('input.bgwcv change.bgwcv').on('input.bgwcv change.bgwcv', '.bgwc-invalid :input', function () {
			var $field = $(this).closest('.gfield');
			if (checkField($field) === true) {
				clearError($field);
			}
		});

		$form.off('blur.bgwce').on('blur.bgwce', 'input[type=email]', function () {
			suggestEmail($(this));
		});

		if (page === 1 && read(SELECT_KEY)) {
			var $pick = $('#' + read(SELECT_KEY));
			store(SELECT_KEY, null);
			if ($pick.length) {
				$pick.prop('checked', true).trigger('click').trigger('change');
				var $choice = $pick.closest('.gchoice').addClass('bgwc-suggested');
				setTimeout(function () {
					scrollTo($choice, -120);
				}, 50);
			}
		}

		if (page === 1) {
			$form.off('change.bgwc').on('change.bgwc', 'input[name="input_2"], input[name="input_3"], input[name="input_4"], input[name="input_29"]', function () {
				remember($form);
				if (this.name === 'input_3' || this.name === 'input_4' || this.name === 'input_29') {
					nudgeFooter($page);
				}
			});
			remember($form);
		} else {
			summaryBar(page);
		}

		// Arriving on a new step: bring it into view, focus the first field on desktop.
		if (lastPage !== null && lastPage !== page) {
			scrollTo($form.closest('.entry'), -16);
			if (finePointer) {
				var $first = $page.find('.gfield:visible').first().find('input[type=text], input[type=email], input[type=tel], textarea').first();
				setTimeout(function () {
					$first.trigger('focus', { preventScroll: true });
				}, reduceMotion ? 0 : 400);
			}
		}
		lastPage = page;
	}

	// Validate before Gravity Forms sends the step; show a loading state when it goes.
	document.addEventListener('click', function (event) {
		var button = event.target.closest && event.target.closest('#gform_' + FORM_ID + ' .gform_next_button, #gform_' + FORM_ID + ' .gform_button');
		if (!button) {
			return;
		}
		var $page = $(button).closest('.gform_page');
		if (!validatePage($page)) {
			event.preventDefault();
			event.stopImmediatePropagation();
			return;
		}
		$(button).addClass('bgwc-loading').attr('aria-busy', 'true');
	}, true);

	// Keep what people typed if a field hides and comes back (e.g. switching who's
	// filling in). Hidden fields are still ignored when the form is submitted.
	if (window.gform && gform.addFilter) {
		gform.addFilter('gform_reset_pre_conditional_logic_field_action', function (reset, formId) {
			return parseInt(formId, 10) === FORM_ID ? false : reset;
		});
	}

	$(document).on('gform_post_render', function (event, formId, page) {
		if (parseInt(formId, 10) !== FORM_ID) {
			return;
		}
		page = parseInt(page, 10) || 1;
		var $form = $('#gform_' + FORM_ID);
		$form.find('.bgwc-summary').remove();

		// Came from "Change" on step 3: keep stepping back to step 1.
		if (read(BACK_KEY) && page > 1) {
			$('#gform_page_' + FORM_ID + '_' + page + ' .gform_previous_button').trigger('click');
			return;
		}
		store(BACK_KEY, null);
		enhance($form, page);
	});
})(jQuery);
